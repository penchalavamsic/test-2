﻿# LIMAS-SUD-2272: whitespace-only-role-name

**Module:** PRF-C — Manage Profile Roles
**Category:** Read-only
**Type:** Functional
**Priority:** Medium
**Status:** Not Run
**Pre-requisite:** Authenticated as SUPER_USER_ADMIN_USER

## Objective
Verify: whitespace-only-role-name

## Steps
1. Navigate to Profiles page
2. Click Manage on a profile card with roles
3. Open the Roles tab
4. Inspect or interact with the target element
5. Assert: Behavior matches the test case title

## Expected Result
The behavior matches the test case title. No runtime data is hardcoded.
