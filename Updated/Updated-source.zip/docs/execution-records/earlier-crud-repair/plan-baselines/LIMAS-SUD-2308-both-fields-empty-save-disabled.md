﻿# LIMAS-SUD-2308: both-fields-empty-save-disabled

**Module:** PRF-D — Create Profile
**Category:** Read-only
**Type:** Functional
**Priority:** Medium
**Status:** Not Run
**Pre-requisite:** Authenticated as SUPER_USER_ADMIN_USER

## Objective
Verify: both-fields-empty-save-disabled

## Steps
1. Navigate to Profiles page
2. Click Create Profile button
3. Inspect or interact with the target element
4. Assert: Behavior matches the test case title

## Expected Result
The behavior matches the test case title. No runtime data is hardcoded.
