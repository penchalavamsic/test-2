# Purpose

Gated Lifecycle Creates Verifies And Deletes A Synthetic Group

# Preconditions

Authenticated as SUPER_USER_ADMIN_USER

# Test Steps



# Expected Final Result


