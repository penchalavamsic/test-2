# Purpose

Child feature Delete disabled when associated with profiles

# Preconditions



# Test Steps



# Expected Final Result


