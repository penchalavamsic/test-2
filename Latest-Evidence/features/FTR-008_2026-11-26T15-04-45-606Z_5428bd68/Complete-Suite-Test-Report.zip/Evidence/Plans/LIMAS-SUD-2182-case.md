# Purpose

Cancel dismisses without uploading

# Preconditions



# Test Steps



# Expected Final Result


