# Purpose

Reopening after Close shows clean state

# Preconditions



# Test Steps



# Expected Final Result


