# Purpose

Gated Lifecycle Creates And Verifies Synthetic Profile

# Preconditions

Authenticated as SUPER_USER_ADMIN_USER

# Test Steps



# Expected Final Result


