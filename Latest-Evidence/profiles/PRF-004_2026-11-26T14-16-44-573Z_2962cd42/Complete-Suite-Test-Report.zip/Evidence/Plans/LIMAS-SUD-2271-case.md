# Purpose

Empty Role Name Rejected

# Preconditions

Authenticated as SUPER_USER_ADMIN_USER

# Test Steps



# Expected Final Result


