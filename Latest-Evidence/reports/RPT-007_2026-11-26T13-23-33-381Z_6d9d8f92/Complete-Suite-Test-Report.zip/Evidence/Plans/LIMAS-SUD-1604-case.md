# Purpose

Loading indicator: spinner visible during Deleted-to-Active switch

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page with Deleted mode

# Test Steps

1. Switch to Deleted. 2. Click Active. 3. Verify loading indicator appears. 4. Verify indicator disappears.

# Expected Final Result

Spinner visible during request. Active data renders after load.
