# Purpose

Reports Standard Licenses RSL-F

# Preconditions

Unfiltered Export

# Test Steps

Reports

# Expected Final Result

API
