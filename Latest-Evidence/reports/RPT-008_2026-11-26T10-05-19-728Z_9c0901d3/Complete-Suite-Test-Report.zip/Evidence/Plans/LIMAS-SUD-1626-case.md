# Purpose

Reports Standard Licenses RSL-F

# Preconditions

Deleted Export

# Test Steps

Reports

# Expected Final Result

Read-only
