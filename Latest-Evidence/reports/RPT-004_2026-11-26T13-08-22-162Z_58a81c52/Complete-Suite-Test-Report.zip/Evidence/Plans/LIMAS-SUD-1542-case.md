# Purpose

No-match Hardware ID: zero results, Clear restores

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Enter no-match HW ID. 2. Verify no results. 3. Clear. 4. Verify unfiltered data returns.

# Expected Final Result

No results for no-match HW ID. Clear restores unfiltered data.
