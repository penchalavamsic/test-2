# Purpose

Reports Floating Configurations RFC-A

# Preconditions

Card Selection

# Test Steps

Reports

# Expected Final Result

Keyboard
