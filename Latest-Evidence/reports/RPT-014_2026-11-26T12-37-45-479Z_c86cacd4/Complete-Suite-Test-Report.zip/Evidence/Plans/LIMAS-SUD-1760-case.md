# Purpose

Reports Floating Configurations RFC-A

# Preconditions

Error State

# Test Steps

Reports

# Expected Final Result

Read-only
