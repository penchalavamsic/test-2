# Purpose

Reports Floating Configurations RFC-A

# Preconditions

Accessibility

# Test Steps

Reports

# Expected Final Result

Accessibility
