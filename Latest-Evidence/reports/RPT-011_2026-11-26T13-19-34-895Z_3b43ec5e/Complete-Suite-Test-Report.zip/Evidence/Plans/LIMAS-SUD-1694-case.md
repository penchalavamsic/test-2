# Purpose

Reports Floating Licenses RFL-C

# Preconditions

Deleted Filters

# Test Steps

Reports

# Expected Final Result

Client-side
