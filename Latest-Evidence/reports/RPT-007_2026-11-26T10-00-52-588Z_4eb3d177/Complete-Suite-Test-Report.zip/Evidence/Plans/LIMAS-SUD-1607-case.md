# Purpose

Active with filter → Deleted switch: filter reset for Deleted

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Apply Email filter in Active. 2. Verify chip and filtered counts. 3. Click Deleted. 4. Verify Deleted loads clean (no filter chip). 5. Verify Deleted count 433.

# Expected Final Result

Active filter not carried to Deleted. Deleted shows unfiltered data. No Email chip in Deleted.
