# Purpose

Email Filter: Enter trigger, debounce, POST request, page reset

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Type email (no Enter). 2. Verify no request. 3. Press Enter. 4. Verify POST to /api/report/standardlicenses. 5. Verify page=0.

# Expected Final Result

Enter triggers POST. page reset to 0. size preserved. email in body.
