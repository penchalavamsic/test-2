# Purpose

No-match email: zero results, empty state, Clear restores

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Enter no-match email. 2. Press Enter. 3. Verify loaded=0, total=0. 4. Click Clear. 5. Verify unfiltered data returns.

# Expected Final Result

loaded=0, total=0. Clear restores unfiltered data and counts.
