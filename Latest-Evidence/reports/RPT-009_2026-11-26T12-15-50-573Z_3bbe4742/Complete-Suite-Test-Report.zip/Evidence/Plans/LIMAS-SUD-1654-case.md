# Purpose

Reports Floating Licenses RFL-A

# Preconditions

Initial Network and Counts

# Test Steps

Reports

# Expected Final Result

API
