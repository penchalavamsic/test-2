# Purpose

Reports Floating Licenses RFL-A

# Preconditions

Active View and Toolbar

# Test Steps

Reports

# Expected Final Result

Read-only
