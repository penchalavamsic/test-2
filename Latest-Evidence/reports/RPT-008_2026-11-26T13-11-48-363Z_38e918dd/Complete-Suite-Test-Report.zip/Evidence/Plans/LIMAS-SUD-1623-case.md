# Purpose

Reports Standard Licenses RSL-F

# Preconditions

Filtered Export

# Test Steps

Reports

# Expected Final Result

Read-only
