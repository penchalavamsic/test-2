# Purpose

Reports Floating Configurations RFC-C

# Preconditions

Accessibility

# Test Steps

Reports

# Expected Final Result

Accessibility
