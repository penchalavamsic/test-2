# Purpose

Profile Role dependency: Profile enables Role, Clear disables

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Verify Profile Role disabled initially. 2. Select Profile. 3. Verify Role enabled. 4. Clear. 5. Verify Role disabled.

# Expected Final Result

Profile Role disabled initially. Enabled after Profile selection. Disabled after Clear.
