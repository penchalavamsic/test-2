# Purpose

Already-selected Active click: no duplicate request, state unchanged

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Ensure Active is pressed. 2. Click Active again. 3. Verify no duplicate network request. 4. Verify state unchanged.

# Expected Final Result

No additional GET request. Active remains pressed. Deleted unpressed. Counts unchanged.
