# Purpose

Reports Floating Licenses RFL-C

# Preconditions

Accessibility

# Test Steps

Reports

# Expected Final Result

Accessibility
