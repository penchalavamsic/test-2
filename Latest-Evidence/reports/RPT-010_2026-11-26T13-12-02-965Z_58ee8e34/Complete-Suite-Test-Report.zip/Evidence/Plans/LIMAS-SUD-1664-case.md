# Purpose

Reports Floating Licenses RFL-B

# Preconditions

Email Filter

# Test Steps

Reports

# Expected Final Result

Read-only
