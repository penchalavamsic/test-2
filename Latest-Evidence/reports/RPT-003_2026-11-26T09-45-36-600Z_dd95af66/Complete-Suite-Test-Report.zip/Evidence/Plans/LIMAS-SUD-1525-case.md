# Purpose

Accessibility: scroll region, keyboard, announcements, focus, end-of-data

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Check table semantics. 2. Check aria-live. 3. Check keyboard reachability. 4. Check sentinel aria-hidden.

# Expected Final Result

Table role, aria-live region, keyboard reachable focusable elements, sentinel aria-hidden=true.
