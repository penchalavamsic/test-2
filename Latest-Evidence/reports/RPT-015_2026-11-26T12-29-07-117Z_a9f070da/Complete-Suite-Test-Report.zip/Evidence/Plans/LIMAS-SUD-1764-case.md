# Purpose

Reports Floating Configurations RFC-B

# Preconditions

Active Error State

# Test Steps

Reports

# Expected Final Result

Read-only
