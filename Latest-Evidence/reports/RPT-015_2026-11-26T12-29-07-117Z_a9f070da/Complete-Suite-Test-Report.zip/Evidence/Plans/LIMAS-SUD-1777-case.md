# Purpose

Reports Floating Configurations RFC-B

# Preconditions

Accessibility

# Test Steps

Reports

# Expected Final Result

Accessibility
