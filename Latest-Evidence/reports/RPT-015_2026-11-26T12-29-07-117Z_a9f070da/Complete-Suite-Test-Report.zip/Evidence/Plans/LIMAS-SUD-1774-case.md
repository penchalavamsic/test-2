# Purpose

Reports Floating Configurations RFC-B

# Preconditions

Mode Switching

# Test Steps

Reports

# Expected Final Result

Race Condition
