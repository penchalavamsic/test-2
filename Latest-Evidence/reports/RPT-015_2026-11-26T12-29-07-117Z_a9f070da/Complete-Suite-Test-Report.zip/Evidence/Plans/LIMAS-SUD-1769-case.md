# Purpose

Reports Floating Configurations RFC-B

# Preconditions

Deleted Table Structure

# Test Steps

Reports

# Expected Final Result

Read-only
