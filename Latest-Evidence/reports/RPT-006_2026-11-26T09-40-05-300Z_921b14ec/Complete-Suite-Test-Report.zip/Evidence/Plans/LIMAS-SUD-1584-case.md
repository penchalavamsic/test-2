# Purpose

Mode control structure: buttons inside group, aria-pressed semantics, keyboard focus

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Verify Active and Deleted buttons inside group "License mode". 2. Verify aria-pressed="true" on Active, "false" on Deleted. 3. Verify native <button> elements. 4. Verify keyboard focusable.

# Expected Final Result

Both buttons present. Group semantics correct. aria-pressed reflects state. Native HTML buttons.
