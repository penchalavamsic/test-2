# Purpose

Active-to-Deleted switch: button press, aria-pressed change, API call

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Click Deleted button. 2. Verify Deleted aria-pressed="true". 3. Verify Active aria-pressed="false". 4. Verify GET allstandarddeleted request fires.

# Expected Final Result

Deleted pressed. Active unpressed. GET /api/report/allstandarddeleted?page=0&size=500. Deleted data loads.
