# Purpose

Accessibility: labels, focus, keyboard navigation

# Preconditions

Authenticated SUPER_USER_ADMIN_USER on Reports page

# Test Steps

1. Verify date labels via parent text. 2. Tab through controls. 3. Verify focus indicators. 4. Verify Clear accessible.

# Expected Final Result

Parent text labels. Tab navigation. Clear accessible. Active stays selected.
