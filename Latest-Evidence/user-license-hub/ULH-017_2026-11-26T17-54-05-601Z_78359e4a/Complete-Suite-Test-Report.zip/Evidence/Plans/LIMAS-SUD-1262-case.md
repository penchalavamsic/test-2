# Purpose

Edit button absent unselected user

# Preconditions

User & License Hub

# Test Steps

ULH-K

# Expected Final Result

Reviewed
