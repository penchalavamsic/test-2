# Purpose

To verify hidden card due to no-match search clears visible selection

# Preconditions



# Test Steps



# Expected Final Result


