# Purpose

To verify applying a Checkout Availability filter shows a filter chip

# Preconditions



# Test Steps



# Expected Final Result


