# Purpose

Floating License Configurations FLC-D

# Preconditions

Capacity Panel

# Test Steps

Floating License Configurations

# Expected Final Result

Read-only
