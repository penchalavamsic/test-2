# Purpose

Floating License Configurations FLC-D

# Preconditions

Dates Panel

# Test Steps

Floating License Configurations

# Expected Final Result

Read-only
