# Purpose

Standard License Configurations SLC-A

# Preconditions

Cards — Identity Fields

# Test Steps

Standard License Configurations

# Expected Final Result

Read-only
