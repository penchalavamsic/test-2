# Purpose

Standard License Configurations SLC-A

# Preconditions

Data Validation — Role Badges

# Test Steps

Standard License Configurations

# Expected Final Result

Read-only
